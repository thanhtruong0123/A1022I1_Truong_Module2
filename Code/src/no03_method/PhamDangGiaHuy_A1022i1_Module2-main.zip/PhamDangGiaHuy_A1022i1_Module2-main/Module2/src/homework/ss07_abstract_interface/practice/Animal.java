package homework.ss07_abstract_interface.practice;

public class Animal {


}

package homework.ss07_abstract_interface.exercise.resizeable;

public interface Resizeable {
    void resize(double percent);
}

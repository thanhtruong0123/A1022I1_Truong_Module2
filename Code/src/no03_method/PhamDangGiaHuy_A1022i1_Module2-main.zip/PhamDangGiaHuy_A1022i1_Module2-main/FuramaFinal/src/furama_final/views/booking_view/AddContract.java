//package furama_final.views.booking_view;
//
//import furama_final.models.Booking;
//import furama_final.models.Contract;
//import furama_final.services.impl.BookingServiceImpl;
//
//public class AddContract {
//    public static Contract add(){
//        BookingServiceImpl bookingService = new BookingServiceImpl();
//        bookingService.display();
//
//
//
//
//
//
//    }
//}

package homework.ss07_abstract_interface.exercise.colorable;

public interface Colorable {
    void howToColor();
}

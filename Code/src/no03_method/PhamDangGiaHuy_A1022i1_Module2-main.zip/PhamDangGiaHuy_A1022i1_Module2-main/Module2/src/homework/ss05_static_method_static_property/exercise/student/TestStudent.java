package homework.ss05_static_method_static_property.exercise.student;

public class TestStudent {
    public static void main(String[] args) {
        Student student = new Student();

        student.setName("GiaHuy");
        student.setClasses("A1022I1");

        System.out.println(student);
    }
}

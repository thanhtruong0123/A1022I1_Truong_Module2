package homework.ss01_array_java.Practice;

public class Test {
    public  static void SumTwo(int a , int b){
        System.out.println(a+b);

    }
    public static void main(String[] args) {
        SumTwo(2,4);

    }
}

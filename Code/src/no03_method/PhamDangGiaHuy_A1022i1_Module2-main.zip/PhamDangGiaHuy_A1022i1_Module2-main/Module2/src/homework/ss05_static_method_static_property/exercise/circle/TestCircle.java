package homework.ss05_static_method_static_property.exercise.circle;

public class TestCircle {
    public static void main(String[] args) {
        Circle testCircle = new Circle();
        System.out.println(testCircle.getRadius());
    }
}

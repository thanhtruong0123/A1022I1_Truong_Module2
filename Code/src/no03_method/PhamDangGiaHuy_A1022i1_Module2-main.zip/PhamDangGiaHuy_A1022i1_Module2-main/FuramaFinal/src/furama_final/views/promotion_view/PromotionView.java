package furama_final.views.promotion_view;

public class PromotionView{
}

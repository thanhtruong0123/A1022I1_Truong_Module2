package homework.ss06_inheritance.practice;

public class ShapeTest {

}
